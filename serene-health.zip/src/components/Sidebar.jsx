import { NavLink, useNavigate } from 'react-router-dom'

const navItems = [
  { to: '/book', icon: 'record_voice_over', label: 'Take Appointment' },
  { to: '/appointments', icon: 'history', label: 'History & Management' },
]

const bottomItems = [
  { to: '/settings', icon: 'settings', label: 'Profile Settings' },
]

export default function Sidebar() {
  const navigate = useNavigate()

  const linkClass = ({ isActive }) =>
    `flex items-center space-x-3 px-4 py-3 rounded-xl transition-all text-sm font-medium font-headline ${
      isActive
        ? 'text-primary font-bold border-r-4 border-primary bg-surface-container-highest'
        : 'text-on-background opacity-80 hover:bg-surface-container-highest'
    }`

  return (
    <nav className="fixed left-0 top-0 h-full flex flex-col p-6 space-y-8 bg-surface-container-low w-72 z-50">
      {/* Brand */}
      <div className="flex items-center space-x-4 px-2">
        <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center overflow-hidden flex-shrink-0">
          <span className="material-symbols-outlined text-on-primary text-2xl">local_hospital</span>
        </div>
        <div>
          <h2 className="text-lg font-bold text-on-surface font-headline">Serene Clinic</h2>
        </div>
      </div>

      {/* Main Nav */}
      <div className="flex-1 space-y-2">
        {navItems.map(({ to, icon, label }) => (
          <NavLink key={to} to={to} className={linkClass}>
            <span className="material-symbols-outlined">{icon}</span>
            <span>{label}</span>
          </NavLink>
        ))}
      </div>

      {/* Bottom Nav */}
      <div className="space-y-2">
        {bottomItems.map(({ to, icon, label }) => (
          <NavLink key={to} to={to} className={linkClass}>
            <span className="material-symbols-outlined">{icon}</span>
            <span>{label}</span>
          </NavLink>
        ))}
        <button
          onClick={() => navigate('/login')}
          className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all text-on-background opacity-80 hover:bg-surface-container-highest text-sm font-medium font-headline"
        >
          <span className="material-symbols-outlined">logout</span>
          <span>Sign Out</span>
        </button>
      </div>
    </nav>
  )
}
